import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class ProductServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    public ProductServlet(){

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      //request.setAttribute("Computer",request.getParameter("Quantity1"));

        HttpSession session = request.getSession();
        session.setAttribute("ComputerQ",request.getParameter("Quantity1"));
        session.setAttribute("LaptopQ",request.getParameter("Quantity2"));
        session.setAttribute("IphoneQ",request.getParameter("Quantity3"));
        session.setAttribute("PhoneQ",request.getParameter("Quantity4"));
        session.setAttribute("ComputerP",request.getParameter("price1"));
        session.setAttribute("LaptopP",request.getParameter("price2"));
        session.setAttribute("IphoneP",request.getParameter("price3"));
        session.setAttribute("PhoneP",request.getParameter("price4"));

        RequestDispatcher rd = request.getRequestDispatcher("CartServlet");
        rd.forward(request,response);





    }
}
