import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

public class CartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }
    public CartServlet(){

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //doGet(request,response);

        HttpSession session = request.getSession();

        String computer = session.getAttribute("ComputerQ").toString();
        String laptop = session.getAttribute("LaptopQ").toString();
        String iphone = session.getAttribute("IphoneQ").toString();
        String phone = session.getAttribute("PhoneQ").toString();
        String computerP = session.getAttribute("ComputerP").toString();
        String laptopP = session.getAttribute("LaptopP").toString();
        String iphoneP = session.getAttribute("IphoneP").toString();
        String phoneP = session.getAttribute("PhoneP").toString();


        response.setContentType("text/html");

        PrintWriter out= response.getWriter();

        out.println("<p align=center>COMPUTER Selected :" + computer +"</p>");
        int i1 = Integer.parseInt(computer) * Integer.parseInt(computerP);
        out.println("<p align=center>Total Price of Computer :" + i1 +"</p>");

        out.println("<p align=center>LAPTOP Selected :" + laptop +"</p>");
        int i = Integer.parseInt(laptop) * Integer.parseInt(laptopP);
        out.println("<p align=center>Total Price of laptop :" + i +"</p>");

        out.println("<p align=center>IPHONE Selected :" + iphone +"</p>");
        int i2 = Integer.parseInt(iphone) * Integer.parseInt(iphoneP);
        out.println("<p align=center>Total Price of iphone :" + i2 +"</p>");

        out.println("<p align=center>SUMSUNG PHONE Selected :" + phone +"</p>");
        int i3 = Integer.parseInt(phone) * Integer.parseInt(phoneP);
        out.println("<p align=center>Total Price of Phone :" + i3 +"</p>");


        int total = i + i1 + i2 + i3;
        out.println("<p align=center>Total Price :" +total +"</p>");
        out.print("<br><a  href=\"CheckOutServlet\"></a><br>   ");
        out.print("<br>   <form align=center action=\"LogoutServlet\" method=\"get\">\n" +
                "        <input type=\"submit\" value=\"Proceed to Checkout\">\n" +
                "    </form>");
        out.print("<br>   <form align=center action=\"LogoutServlet\" method=\"get\">\n" +
                "        <input type=\"submit\" value=\"Update Cart\">\n" +
                "    </form>");
        out.print("<br>   <form align=center action=\"LogoutServlet\" method=\"get\">\n" +
                "        <input type=\"submit\" value=\"Logout\">\n" +
                "    </form>");





        RequestDispatcher rd= request.getRequestDispatcher("Cart.html");

        rd.include(request,response);



    }
}
