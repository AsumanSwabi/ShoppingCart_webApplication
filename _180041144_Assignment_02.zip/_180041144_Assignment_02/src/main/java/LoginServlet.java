import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends HttpServlet {
    private final String name = "user";
    private final String password = "pass";
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username-field");
        String pw = request.getParameter("pw-field");

//        PrintWriter out = response.getWriter();
        PrintWriter out = response.getWriter();
        if (username.equals(name) && pw.equals(password))
        {
// Using cookies to manage sessions
            System.out.println("<h1> Successfully logged in </h1>");
            Cookie usernameCookie = new Cookie("currentUser", username);
            usernameCookie.setMaxAge(30*60);
            response.addCookie(usernameCookie);
            RequestDispatcher rd = request.getRequestDispatcher("Product.html");
            //rd.forward(request, response);
            rd.include(request, response);
        }
        else
        {
            out.println("<h1 align=center> Wrong credentials </h1>");

            RequestDispatcher rd = request.getRequestDispatcher(
                    "index.html");
            rd.include(request, response);
        }
        }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
